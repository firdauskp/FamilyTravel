<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PesanModel extends CI_Model {
	public function getPesan($id){
        $this->db->where('id_jadwal', $id);
        $res = $this->db->get('jadwal')->result_array();
        return $res;
    }
}