<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProfileModel2 extends CI_Model {
	public function getUser($no_ktp){
        $this->db->where('no_ktp',$no_ktp);
        $res = $this->db->get('user')->result_array();
        return $res;
    }

	function input_data($data,$table){
		$this->db->insert($table,$data);
	}

	function hapus_data($where,$table){
		$this->db->where($where);
		$this->db->delete($table);
	}

	function edit_data($where,$table){		
		return $this->db->get_where($table,$where);
	}

	function update_data($id,$data){
		$this->db->where('no_ktp',$id);
		$this->db->update('user',$data);
	}
}

/* End of file modelName.php */
/* Location: ./application/models/modelName.php */
