<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProfileModel extends CI_Model {
	public function UpdateUser($user_id, $data)
	{
		$this->db->set($data);
		$this->db->where('id', $user_id);
		$this->db->update('users');

		if ($this->db->affected_rows() > 0) {
			return true;
		} else {
			return false;
		}
	}
	

}

/* End of file ProfileModel.php */
/* Location: ./application/models/ProfileModel.php */