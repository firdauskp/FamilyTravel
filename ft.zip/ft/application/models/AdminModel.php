<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AdminModel extends CI_Model {
	public function insertData($table,$data){
		$res = $this->db->insert($table, $data);
		return $res;
	}
}
