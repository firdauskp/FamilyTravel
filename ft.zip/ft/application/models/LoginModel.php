<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class LoginModel extends CI_Model {
	public function loginReq($email,$password)
	{
        $this->db->where('email_user', $email);
        $this->db->where('password', $password);
        $res = $this->db->get('user')->result_array();
        return $res;
        }
        
        public function getUser($no_ktp){
                $this->db->where('no_ktp',$no_ktp);
                $res = $this->db->get('user')->result_array();
                return $res;
        }
}