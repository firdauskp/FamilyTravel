<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Supir extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('loginmodel');
	}
	 
	public function loggedIn()
	{
		$no_ktp = $this->session->userdata['no_ktp'];
		$d = $this->loginmodel->getUser($no_ktp);
		foreach ($d as $datz){
			$nama = $datz['nama_user'];
			$email = $datz['email_user'];
		}
		$data['nama'] = $nama;
		$data['email'] = $email;
        $data['css'] = 'theme.css';
		$data['judul'] = 'Supir';
        $data['data'] = $data;
        $this->load->view('header-profile',$data);
        $this->load->view('supir');
        $this->load->view('footer');
	}
}
