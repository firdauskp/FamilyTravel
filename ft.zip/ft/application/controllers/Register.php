<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->model('InsertModel');
	}

	public function index()
	{
        $data['css'] = 'theme.css';
        $data['judul'] = 'Registration';
        $data['data'] = $data;
        $this->load->view('header',$data);
        $this->load->view('register');
        $this->load->view('footer');
	}

	public function addAkun(){
		$nama = $_POST['nama'];
		$noTlp = $_POST['noTlp'];
		$noKtp = $_POST['noKtp'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$jenisAkun = $_POST['jenisAkun'];
		$alamat = $_POST['alamat'];

		$data = array(
			'nama_user' => $nama,
			'alamat_user' => $alamat,
			'no_ktp' => $noKtp,
			'no_telp_user' => $noTlp,
			'email_user' => $email,
			'password' => $password,
			'jenisAkun' => $jenisAkun
		);

		$res = $this->InsertModel->insertData('user', $data);

		if ($data['jenisAkun'] == 'admin'){
			$data = array(
				'id_admin' => null,
				'no_ktp' => $noKtp
			);
			$res = $this->InsertModel->insertData('admin', $data);
		}elseif ($data['jenisAkun'] == 'customer'){
			$data = array(
				'id_customer' => null,
				'no_ktp' => $noKtp
			);
			$res = $this->InsertModel->insertData('customer', $data);
		}elseif ($data['jenisAkun'] == 'supir'){
			$data = array(
				'id_supir' => null,
				'no_ktp' => $noKtp
			);
			$res = $this->InsertModel->insertData('supir', $data);
		}
		if($res)
        {
            echo '<script>alert("Registrasi Berhasil");</script>';
            redirect('home', 'refresh');
        }
        else{
            $this->session->set_flashdata("message","Maaf registrasi gagal");
            redirect('home', 'refresh');
        }
	}
}

		
