<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pesan extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->model('loginmodel');
		$this->load->model('pesanmodel');
	}

	public function index()
	{
		$log = $this->session->userdata['logged_in'];
		$no_ktp = $this->session->userdata['no_ktp'];
		if($log){
			$d = $this->loginmodel->getUser($no_ktp);
			foreach ($d as $datz){
				$nama = $datz['nama_user'];
			}
			$data['css'] = 'theme.css';
			$data['judul'] = 'Pesan';
			$data['nama'] = $nama;
			$data['data'] = $data;
			$this->load->view('header-logged-in', $data);
			$this->load->view('pesan');
			$this->load->view('footer');
		}else{
			redirect('login');
		}
	}

	public function pezan($id_jadwal){
		$log = $this->session->userdata['logged_in'];
		$no_ktp = $this->session->userdata['no_ktp'];
		if($log){
			$d = $this->loginmodel->getUser($no_ktp);
			$b = $this->pesanmodel->getPesan($id_jadwal);
			foreach ($d as $datz){
				$nama = $datz['nama_user'];
			}
			foreach ($b as $datz){
				$asal = $datz['Asal'];
				$tujuan = $datz['Tujuan'];
				$waktu = $datz['waktu_keberangkatan'];
			}
			$data['asal'] = $asal;
			$data['tujuan'] = $tujuan;
			$data['waktu'] = $waktu;
			$data['css'] = 'theme.css';
			$data['judul'] = 'Pesan';
			$data['nama'] = $nama;
			$data['data'] = $data;
			$this->load->view('header-logged-in', $data);
			$this->load->view('pesan-spesifik');
			$this->load->view('footer');
		}else{
			redirect('login');
		}
	}
}
