<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile2 extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('profilemodel2');
	}
	public function index(){
		$id = $this->session->userdata('no_ktp');
		$d = $this->profilemodel2->getUser($id);
		foreach ($d as $datz){
			$data["nama"] = $datz['nama_user'];
			$data["noTlp"] = $datz['no_telp_user'];
			$data['noKtp'] = $datz['no_ktp'];
			$data['email'] = $datz['email_user'];
			$data['alamat'] = $datz['alamat_user'];
		}
		$data['css'] = 'theme.css';
        $data['judul'] = 'Profil';
        $data['data'] = $data;
        $this->load->view('header-profile',$data);
        $this->load->view('Profile2');
        $this->load->view('footer');
	}

	public function edit($id){
		$nama = $_POST["nama"];
		$noTlp = $_POST["noTlp"];
		$password = $_POST["password"];
		$alamat = $_POST['alamat'];
		$data = array(
		       'nama_user' => $nama,
		       'no_telp_user' => $noTlp,
		       'password' => $password,
		       'alamat_user' => $alamat
		);
		$res = $this->profilemodel2->update_data($id,$data);
		redirect('profile2');
	}
}
/* End of file Profil.php */
/* Location: ./application/controllers/Profil.php */