<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {
	public function index()
	{
		$data['css'] = 'theme.css';
		$data['judul'] = 'Login';
        $data['data'] = $data;
        $this->load->view('header',$data);
        $this->load->view('login');
        $this->load->view('footer');
	}

	public function loginVal(){
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		$this->load->model('loginmodel');
		$this->loginmodel->loginReq($email,$password);

		if($query = $this->loginmodel->loginReq($email,$password)){
			foreach ($query as $data){
				$session_data = array(
					'no_ktp' => $data['no_ktp'],
					'logged_in' => TRUE,
					'jenisAkun' => $data['jenisAkun']
				);
			}
			$this->session->set_userdata($session_data);
			if($this->session->userdata('jenisAkun') == 'admin'){
				redirect('admin/loggedIn');
			}elseif($this->session->userdata('jenisAkun') == 'supir'){
				redirect('supir/loggedIn');
			}elseif($this->session->userdata('jenisAkun') == 'customer'){
				redirect('home/loggedIn');
			}
		}else{
			$this->session->set_flashdata('item','maaf email atau password yang masukkan salah');
			redirect('login');
		}
	}
}
