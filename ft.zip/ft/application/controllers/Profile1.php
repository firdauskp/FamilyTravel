<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
	
	public function __construct()
	{
		parent::__construct();
		//load model users
		$this->load->model('ProfilModel', 'ProfileModel');
	}
	public function index()
	{
		//jika form profile disubmit jalankan 
		if ($this->input->post('submit_information')) {
			//validasi data
			$this->form_validation->set_rules('nama', 'Nama', 'required');
			$this->form_validation->set_rules('noTlp', 'Nomor Telepon', 'required');
			$this->form_validation->set_rules('noKtp', 'Nomor Identitas', 'required');
			$this->form_validation->set_rules('email', 'E-mail', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');
			
			//mengatur pesan error validasi data
			$this->form_validation->set_message('required', '%s tidak boleh kosong');

			//jalankan validasi jika true
			if ($this->form_validation->run() == TRUE) {
				$data['nama'] = $this->input->post('nama');
				$data['noTlp'] = $this->input->post('noTlp');
				$data['noKtp'] = $this->input->post('noKtp');
				$data['email'] = $this->input->post('email');
				$data['password'] = $this->input->post('password');

				$query = $this->model_user->update($data['noKtp'], $data); 

				if ($query) {
					//set success message
					$message = array('status' => true, 'message' =>'Berhasil memperbarui' );

					//update session baru
					$this->session->set_userdata($data);
				} else {

					//set error message
					$message = array('status' => false, 'message' =>'Gagal memperbarui' );
				}

				//simpan message sebagai session 
				$this->session->flashdata('message_profile', $message);
				
				//refresh page
				redirect('profile','refresh');	
			}

		}
		//data untuk page profile
		$data['css'] = 'theme.css';
        $data['judul'] = 'Profile';
        $data['data'] = $data;
        $this->load->view('header-profile',$data);
        $this->load->view('Profile');
        $this->load->view('footer');
	}
	public function cekPasswordLama()
	{
		//ambil noKtp
		$noKtp = $this->session->userdata('id');

		//ambil data password_lama dari POST
		$password = $this->input->POST('password_lama');

		//jalankan function cekPasswordLama pada model_users
		$query = $this->model_users->cekPasswordLama($noKtp, $password);

		//jika query gagal return false
		if($query){
			//mengatur  pesan error validasi data
			$this->form_validation->set_message('cekPasswordLama', 'password gagal diganti');
			return false;
		}
		return true;
	}
}

/* End of file Profile.php */
/* Location: ./application/controllers/Profile.php */