
  <div class="py-5" style="background-image: url(<?= base_url()?>assets/img/bg.svg); background-position:left center; background-size: cover; color: white;">
    <div class="container">
      <div class="row">
        <div class="col-lg-8 p-md-5 p-3 d-flex flex-column justify-content-center">
          <h1>Family Travel</h1>
          <p class="mb-0">Kebutuhan masyarakat atas transportasi jalur darat mendorong kami untuk menjadi bisnis travel yang selalu dekat dengan masyarakat. Hal ini dapat dilihat dengan usaha kami menyediakan lebih dari 30 outlet pelayanan travel yang tersebar di kota Jakarta serta bandung dan sekitarnya.</p>
        </div>
        <div class="col-lg-4 p-3">
          <div id="carousel2" class="carousel slide" data-ride="carousel" data-interval="5000">
            <div class="carousel-inner">
              <div class="carousel-item"> <img class="imej" src="<?= base_url()?>assets/img/1.jpg"> </div>
              <div class="carousel-item active"> <img class="imej" src="<?= base_url()?>assets/img/2.jpg"> </div>
              <div class="carousel-item"> <img class="imej" src="<?= base_url()?>assets/img/3.jpg"> </div>
              <div class="carousel-item"> <img class="imej" src="<?= base_url()?>assets/img/4.jpg"> </div>
            </div>
            <a class="carousel-control-prev" href="#carousel2" role="button" data-slide="prev">
              <span class="carousel-control-prev-icon" aria-hidden="true"></span></a>
            <a class="carousel-control-next" href="#carousel2" role="button" data-slide="next">
              <span class="carousel-control-next-icon" aria-hidden="true"></span></a>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="text-center mx-auto col-md-8">
          <h1 class="mb-3">Tempat &amp; Jadwal</h1>
        </div>
      </div>
      <div class="row pezan">
        <div id="cek" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/5"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/bdg.jpg"></a> </div>
        <div id="cek2" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/6"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/bgr.jpg"></a> </div>
        <div id="cek3" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/7"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/clg.jpg"></a> </div>
        <div id="cek4" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/8"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/crbn.jpg"></a> </div>
        <div id="cek5" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/9"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/jkt.jpg"></a> </div>
        <div id="cek6" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/10"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/smr.jpg"></a> </div>
        <div id="cek7" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/11"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/srg.jpg"></a> </div>
        <div id="cek8" class="col-lg-3 col-md-1 p-3"> <a href="<?= base_url()?>pesan/pezan/12"><img class="img-fluid d-block" src="<?= base_url()?>assets/img/tgr.jpg"></a> </div>
      </div>
    </div>
  </div>
  <!-- <script src="<?= base_url()?>assets/js/home.js"></script> -->