
  <div class="py-5" style="background-image: url('https://static.pingendo.com/cover-stripes.svg'); background-position:left center; background-size: cover;">
    <div class="container">
      <div class="row">
        <div class="p-5 col-lg-6">
          <h1>Log In</h1><br>
          <form method='post' action='<?= base_url()?>login/loginVal'>
            <div class="form-group"> <input type="email" class="form-control" placeholder="Enter email" name='email'> </div>
            <div class="form-group"> <input type="password" class="form-control" placeholder="Password" name='password'> <small class="form-text text-muted text-right">
                <p style="color: #B33A3A"><?= $this->session->flashdata('item')?></p>
                <a href="#"> Forgot your password?</a>
              </small> </div> <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  