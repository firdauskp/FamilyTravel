
  <div class="py-5 text-center" style="	background-image: url(&quot;https://static.pingendo.com/cover-stripes.svg&quot;);	background-position: top left;	background-size: cover;	background-repeat: repeat;">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-6 col-10">
          <h1>Edit Profile</h1><br>
          <form class="text-left" method='post' action='<?= base_url()?>Profile2/edit/<?= $data['noKtp']?>'>
            <div class="form-group"> <label>Nama</label> <input type="text" name='nama' class="form-control" value="<?= $data['nama']?>" required> </div>
            <div class="form-group"> <label>Nomor Telepon</label> <input type="text" name='noTlp' class="form-control" value="<?= $data['noTlp']?>"> </div>
            <div class="form-group"> <label>Nomor Identitas</label> <input type="text" name='noKtp' class="form-control" value="<?= $data['noKtp']?>" required readonly> </div>
            <div class="form-group"> <label>E-mail</label> <input type="email" name='email' class="form-control" value="<?= $data['email']?>" required readonly> </div>
            <div class="form-group"> <label>Password</label> <input type="password" name='password' class="form-control" required> </div>
            <div class="form-group"> <label>Alamat</label> <textarea name='alamat' value="<?= $data['alamat']?>" class="form-control" style="margin-top: 0px; margin-bottom: 0px; height: 102px;"></textarea></div>
            <div class="form-group">
              <div class="form-check"> <input class="form-check-input" type="checkbox" id="form21" value="on"> <label class="form-check-label" for="form21"> I Agree with <a href="#">Term and Conditions</a> of the service </label> </div>
            </div> <button type="submit" class="btn btn-primary">Edit Profile</button>
          </form>
        </div>
      </div>
    </div>
  </div>
