
  <div class="py-5 text-center" style="	background-image: url(&quot;https://static.pingendo.com/cover-stripes.svg&quot;);	background-position: top left;	background-size: cover;	background-repeat: repeat;">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-6 col-10">
          <h1>Pemesanan Tiket</h1><br>
          <form class="text-left">
            <div class="form-group"> <label for="form16">Asal</label> <input type="text" class="form-control" id="form16" value="<?= $data['asal']?>"> </div>
            <div class="form-group" style=""> <label for="form17">Tujuan</label> <input type="text" class="form-control" id="form17" value="<?= $data['tujuan']?>"> </div>
            <div class="form-group"> <label for="form17">Waktu</label> <input type="text" class="form-control" id="form17" value="<?= $data['waktu']?>"> </div>
            <div class="form-group"> <label for="form17">Jumlah Tiket</label> <input type="number" class="form-control" id="form17" placeholder="" min='0'> </div>
            <button type="submit" class="btn btn-primary">Pesan<br></button>
          </form>
        </div>
      </div>
    </div>
  </div>
  