<div class="py-3 bg-dark">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-6 p-3"> <i class="fa fa-5x text-primary fa-car d-block"></i> </div>
        <div class="col-lg-4 col-6 p-3">
          <p> <a href="https://goo.gl/maps/AUq7b9W7yYJ2" target="_blank"> Jalan Kung King Kang, 100 <br>Kab. Neptunus - 20179, Pluto</a> </p>
          <p> <a href="tel:+246 - 542 550 5462">+651 - 984 113 845</a> </p>
          <p class="mb-0"> <a href="mailto:family@travel.com">family@travel.com</a> </p>
        </div>
        <div class="col-md-4 p-3">
          <h5 class="text-body"> <b>About</b> </h5>
          <p class="mb-0 text-body"> Dengan slogan sedekah itu baik-jujur itu keren, kami berharap agar layanan ini mampu dirasakan oleh semua kalangan masyarakat. Karena kami ingin membuktikan bahwa pelayanan yang kami berikan mampu dinikmati oleh semua kalangan tanpa melihat perbedaan apapun.</p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-12 text-center">
          <p class="mb-0 mt-2 text-body">© 2018 Family Travel. All rights reserved</p>
        </div>
      </div>
    </div>
  </div>
  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous" style=""></script>
</body>

</html>