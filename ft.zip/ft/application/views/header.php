<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="<?= base_url();?>assets/css/<?= $data['css'];?>" type="text/css">
  <title>Family Travel - <?= $data['judul'];?></title>
  <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url()?>assets/img/favicon.png">
</head>

<body class="bg-light">
  <nav class="navbar navbar-expand-md navbar-dark bg-dark">
    <a class="navbar-brand mb-0 text-white" href="<?= base_url()?>home"><i class="fa d-inline fa-lg fa-car"></i> <b>FAMILY TRAVEL</b></a> <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbar2SupportedContent"> <span class="navbar-toggler-icon"></span> </button>
    <div class="collapse navbar-collapse text-center justify-content-end" id="navbar2SupportedContent">
      <ul class="navbar-nav">
        <li class="nav-item"> <a class="nav-link" href="<?= base_url()?>home"><i class="fa d-inline fa-home fa-lg"></i>&nbsp;Home</a> </li>
        <li class="nav-item"> <a class="nav-link" href="<?= base_url()?>pesan"><i class="fa d-inline fa-lg fa-bookmark-o"></i>&nbsp;Pesan</a> </li>
      </ul>
      <div class="row">
        <div class="col-md-12">
          <div class="btn-group">
            <button class="btn dropdown-toggle btn-outline-success" data-toggle="dropdown" aria-expanded="false"><i class="fa d-inline fa-lg fa-user-circle-o"></i> Login/Register </button>
            <div class="dropdown-menu"> <a class="dropdown-item" href="<?= base_url()?>login">Login</a>
              <div class="dropdown-divider"></div> <a class="dropdown-item" href="<?= base_url()?>register">Register</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </nav>