
  <div class="py-5 text-center" style="	background-image: url(&quot;https://static.pingendo.com/cover-stripes.svg&quot;);	background-position: top left;	background-size: cover;	background-repeat: repeat;">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-6 col-10">
          <h1>Registration</h1><br>
          <form class="text-left" method='post' action='<?= base_url()?>register/addAkun'>
            <div class="form-group"> <label>Nama</label> <input type="text" name='nama' class="form-control" placeholder="Nama" required> </div>
            <div class="form-group"> <label>Nomor Telepon</label> <input type="text" name='noTlp' class="form-control" placeholder="081xxx"> </div>
            <div class="form-group"> <label>Nomor Identitas</label> <input type="text" name='noKtp' class="form-control" placeholder="KTP/SIM/KTM/dsb." required> </div>
            <div class="form-group"> <label>E-mail</label> <input type="email" name='email' class="form-control" placeholder="nama@email.com" required> </div>
            <div class="form-group"> <label>Password</label> <input type="password" name='password' class="form-control" placeholder="Password" required> </div>
            <div class="form-group">
              <label>Jenis Akun</label>
              <select name="jenisAkun" class='form-control'>
                <option value="customer">Customer</option>
                <option value="supir">Supir</option>
              </select>
            </div>
            <div class="form-group"> <label>Alamat</label> <textarea name='alamat' class="form-control" style="margin-top: 0px; margin-bottom: 0px; height: 102px;" placeholder="Jln. Pegangsaan Timur"></textarea></div>
            <div class="form-group">
              <div class="form-check"> <input class="form-check-input" type="checkbox" id="form21" value="on"> <label class="form-check-label" for="form21"> I Agree with <a href="#">Term and Conditions</a> of the service </label> </div>
            </div> <button type="submit" class="btn btn-primary">Register</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  