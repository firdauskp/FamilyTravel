
      <div class="row">
        <div class="col-md-6">
          <div class="my-5">
            <table class="table table-bordered table-hover table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Jadwal</th>
                  <th>Tujuan</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Senin, 26-08-18 / 14.30</td>
                  <td>Papua</td>
                </tr>
                <tr>
                  <td>1</td>
                  <td>Senin, 26-08-18 / 14.30</td>
                  <td>Papua</td>
                </tr>
                <tr>
                  <td>1</td>
                  <td>Senin, 26-08-18 / 14.30</td>
                  <td>Papua</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-md-6">
          <img class="img-fluid d-block mx-auto rounded-circle" src="<?= base_url()?>assets/img/bobotohbanyol_Bh1REmQhVLZ.jpg" style="min-width: 125px; min-height: 125px; max-width: 250px; max-height: 250px;">
          <div class="text-center my-2">
            <p class="lead">Nama : <?= $data['nama']?></p>
            <p class="lead">Email : <?= $data['email']?></p><a class="btn btn-primary" href="<?= base_url()?>logout">Log Out</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  