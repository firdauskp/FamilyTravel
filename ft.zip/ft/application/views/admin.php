
      <div class="row">
        <div class="col-md-6">
          <ul class="nav nav-tabs">
            <li class="nav-item">
              <a href="#jadwal" class="nav-link active show" aria-controls="jadwal" aria-selected="true" data-toggle="tab" id="jadwal-tab" role="tab">Input Jadwal</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#kendaraan" aria-controls="kendaraan" aria-selected="false" data-toggle="tab" id="kendaraan-tab" role="tab">Input Kendaraan</a>
            </li>
            <li class="nav-item">
              <a href="#supir" class="nav-link" aria-controls="supir" aria-selected="false" data-toggle="tab" id="supir-tab" role="tab">Input Data Supir</a>
            </li>
          </ul>
          <div class="tab-content my-2" id="myTabContent">
            <div class="tab-pane fade active show" id="jadwal" role="tabpanel" aria-labelledby="jadwal-tab" style="">
              <h1 class="mb-4 text-center" style="">Input Jadwal </h1>
              <form method='post' action='<?= base_url()?>admin/inputJadwal'>
                  <div class="form-group"> <input type="text" name='waktu' class="form-control" placeholder="Waktu" > </div>
                  <div class="form-group"> <input type="text" name='asal' class="form-control" placeholder="Asal"> </div>
                <div class="form-group"> <input type="text" name='tujuan' class="form-control" placeholder="Tujuan"> </div>
                <div class="form-group"> <small class="form-text text-muted text-right"></small> </div> <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
            <div class="tab-pane fade" id="kendaraan" role="tabpanel" aria-labelledby="kendaraan-tab">
              <h1 class="mb-4 text-center">Input Data Kendaraan </h1>
              <form method='post' action='<?= base_url()?>admin/inputKendaraan'>
                <div class="form-group"> <input type="text" name='plat' class="form-control" placeholder="Plat Nomor"> </div>
                <div class="form-group"> <input type="text" name='merk' class="form-control" placeholder="Merk Kendaraan"> </div>
                <div class="form-group"> <small class="form-text text-muted text-right"></small> </div> <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
            <div class="tab-pane fade" id="supir" role="tabpanel" aria-labelledby="supir-tab">
              <h1 class="mb-4 text-center" style="">Input Data Supir</h1>
              <form>
                <div class="form-group"> <input type="text" class="form-control" placeholder="Nama" id="form13"> </div>
                <div class="form-group"> <input type="text" class="form-control" placeholder="Merk Kendaraan" id="form13"> </div>
                <div class="form-group"> <input type="email" class="form-control" placeholder="Email" id="form14"> </div>
                <div class="form-group"> <input type="password" class="form-control" placeholder="Password" id="form15"> <small class="form-text text-muted text-right"></small> </div> <button type="submit" class="btn btn-primary">Submit</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <img class="img-fluid d-block mx-auto rounded-circle" src="<?= base_url()?>assets/img/bobotohbanyol_Bh1REmQhVLZ.jpg" style="min-width: 125px; min-height: 125px; max-width: 250px; max-height: 250px;">
          <div class="text-center my-2">
            <p class="lead">Nama : <?= $data['nama']?></p>
            <p class="lead">Email : <?= $data['email']?></p><a class="btn btn-primary" href="<?= base_url()?>logout">Log Out</a>
          </div>
        </div>
      </div>
    </div>
  </div>
  