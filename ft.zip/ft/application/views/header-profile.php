<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- PAGE settings -->
  <link rel="icon" type="image/png" sizes="16x16" href="<?= base_url()?>assets/img/favicon.png">
  <title><?= $data['judul'];?></title>
  <meta name="author" content="Pingendo">
  <!-- CSS dependencies -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
  <link rel="stylesheet" href="<?= base_url()?>assets/css/theme.css" type="text/css">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container d-flex justify-content-center"> <a class="navbar-brand" href="<?= base_url()?>home/loggedIn">
        <i class="fa d-inline fa-lg fa-car"></i>
        <b>FAMILY TRAVEL</b>
      </a> </div>
</nav>