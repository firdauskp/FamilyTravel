
  <div class="py-5 text-center" style="	background-image: url(&quot;https://static.pingendo.com/cover-stripes.svg&quot;);	background-position: top left;	background-size: cover;	background-repeat: repeat;">
    <div class="container">
      <div class="row">
        <div class="mx-auto col-lg-6 col-10">
          <h1>Profil</h1><br>
          <form class="text-left" method='post' action='<?= base_url()?>Profile'>
            <div class="form-group"> <label>Nama</label> <input type="text" name='nama' class="form-control" placeholder="nama" required> </div>
            <div class="form-group"> <label>Nomor Telepon</label> <input type="text" name='noTlp' class="form-control" placeholder="nomor telepon"> </div>
            <div class="form-group"> <label>Nomor Identitas</label> <input type="text" name='noKtp' class="form-control" placeholder="nomor identitas" required> </div>
            <div class="form-group"> <label>E-mail</label> <input type="email" name='email' class="form-control" placeholder="email" required> </div>
            <div class="form-group"> <label>Password</label> <input type="password" name='password' class="form-control" placeholder="password" required> </div>
            <div class="form-group"> <label>Alamat</label> <textarea name='alamat' class="form-control" style="margin-top: 0px; margin-bottom: 0px; height: 102px;" placeholder="alamat"></textarea></div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
    </div>
  </div>
  
